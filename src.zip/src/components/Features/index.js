export { default as QrShare } from "./QrShare";
