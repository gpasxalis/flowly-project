export { default as Footer } from "./Footer";
