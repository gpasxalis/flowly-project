export { default as InfoCard } from "./InfoCard";
